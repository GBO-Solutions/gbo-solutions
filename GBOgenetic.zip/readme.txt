1) topics:
   - maximization of function with boundaries
   - it's necessary that the function takes positive (non-zero) value at any point of the range
   - appled to linear and non-linear problems
   - the optimization is not trapped in local stationary point (min, max or inflection)

2) running:
   opt,sol = module.gbo_genetic(Fun,Argume,Ranges,Decimal,Pmut,LoopMax)
   - Fun: objective function ---> Fun(OpVal,Argume)
   - Argume: list of extra arguments for Fun
   - Ranges: list of variables ranges
             each elements of this list consist of a tuple:
              i) lower value of range
             ii) upper value of range
   - Decimal: decimal accuracy of results
   - Pmut: probability of mutation
   - LoopMax: number of generations/iterations

3) necessary installed modules:
   - datetime
   - random

4) output file:
   - steps.txt: the results of the optimization process at each step are recorded
