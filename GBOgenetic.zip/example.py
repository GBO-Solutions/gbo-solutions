import math,module

def f(x,const):
    return const[0]+math.exp(-(x[0]**2.0+x[1]**2.0)/5.0)*math.cos(x[0]**2.0+x[1]**2.0)

module.gbo_genetic(Fun=f,Argume=[1.0,],Ranges=[(-2.0,2.0),(-2.0,2.0)],Decimal=1,NumPop=50,Pmut=0.025,LoopMax=250)
