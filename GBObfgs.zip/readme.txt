1) topics:
   - maximization of function with boundaries
   - appled to lintear and non-linear problems
   - may converge to any stationary point (min, max or inflection)

2) running:
   opt,sol = module.gbo_bfgs(Fun,OpVal,Argume,Ranges,Conver)
   - Fun: objective function ---> Fun(OpVal,Argume) 
   - OpVal: list of initial values
   - Argume: list of extra arguments for Fun
   - Ranges: list of variables ranges
             each element of this list consists of a tuple:
               i) True/False for strict/relaxed range, respectivly
              ii) lower value of range
             iii) upper value of range
   - Conver: convergece limit of the optimization procedure

3) necessary installed modules:
   - math
   - numpy

4) output file:
   - steps.txt: the results of the optimization process at each step are recorded
