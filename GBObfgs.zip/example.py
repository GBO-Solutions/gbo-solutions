import math,module

def f(x,const):
    return const[0]+x[0]*math.exp(-x[0])

module.gbo_bfgs(Fun=f,OpVal=[0.05,],Argume=[0.0,],Ranges=[(True,0.0,0.90),],Conver=0.000001)
