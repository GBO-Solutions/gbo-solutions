import math
import numpy as np
from numpy.linalg import inv

def number(num):
    if num==0:
        return '00'
    elif num==1:
        return '01'
    elif num==2:
        return '02'
    elif num==3:
        return '03'
    elif num==4:
        return '04'
    elif num==5:
        return '05'
    elif num==6:
        return '06'
    elif num==7:
        return '07'
    elif num==8:
        return '08'
    elif num==9:
        return '09'
    else:
        return str(num)

def record(num,OpVal,Fun,Jmat,Hmat):
    with open('./steps.txt','a+') as f:
        f.write('  %d    '%(num))
        for i in range(0,len(OpVal)):
            f.write('%.5f   '%(OpVal[i]))
        f.write('[')
        for i in range(0,len(Jmat)):
            f.write('%.5f, '%(Jmat[i][0]))
        f.write('] [')
        for i in range(0,len(Hmat)):
            f.write('[')
            for j in range(0,len(Hmat[i])):
                f.write('%.5f, '%(Hmat[i][j]))
            f.write('],')
        f.write(']   %.5f\n'%(Fun))

def jaco(Fun,OpVal,Argume,Ranges):
    Bcoef = [min([1.0-math.exp(-(OpVal[i]-Ranges[i][1])**2.0),1.0-math.exp(-(OpVal[i]-Ranges[i][2])**2.0)]) if Ranges[i][0]==True else 1.0 for i in range(0,len(Ranges))]
    delta = [(Ranges[i][2]-Ranges[i][1])/1000.0 for i in range(0,len(Ranges))]
    Jmat = []
    for i in range(0,len(OpVal)):
        F1 = Fun([OpVal[j]-delta[j] if i==j else OpVal[j] for j in range(0,len(OpVal))],Argume)
        F2 = Fun([OpVal[j]+delta[j] if i==j else OpVal[j] for j in range(0,len(OpVal))],Argume)
        Jmat .append([Bcoef[i]*(F2-F1)/(2.0*delta[i]),])
    return (F1+F2)/2.0,np.array(Jmat)

def jac_hes0(Fun,OpVal,Argume,Ranges,F0):
    delta = [(Ranges[i][2]-Ranges[i][1])/1000.0 for i in range(0,len(Ranges))]
    Jmat,Hmat = [],[]
    for i in range(0,len(OpVal)):
        F1 = Fun([OpVal[j]-delta[j] if i==j else OpVal[j] for j in range(0,len(OpVal))],Argume)
        F2 = Fun([OpVal[j]+delta[j] if i==j else OpVal[j] for j in range(0,len(OpVal))],Argume)
        Jmat .append([(F2-F1)/(2.0*delta[i]),])
        Hmat.append([(F2-2.0*F0+F1)/(delta[j]**2.0) if i==j else 0.0 for j in range(0,len(OpVal))])
    return np.array(Jmat),np.array(Hmat)

def hess(OpVal,Jmat,Hmat,OpVal_new,Jmat_new):
    try:
        Smat = [[OpVal_new[j]-OpVal[j],] for j in range(0,len(OpVal_new))]
        Ymat = [[Jmat_new[j][0]-Jmat[j][0],] for j in range(0,len(Jmat_new))]
        Hmat_new = Hmat-np.matmul(np.matmul(np.matmul(Hmat,Smat),np.transpose(Smat)),Hmat)/np.matmul(np.matmul(np.transpose(Smat),Hmat),Smat)[0][0]+np.matmul(Ymat,np.transpose(Ymat))/np.matmul(np.transpose(Ymat),Smat)[0][0]
    except:
        Hmat_new = np.identity(len(OpVal))
    return np.array(Hmat_new)

def bfgs(Fun,OpVal,Argume,Ranges,Conver):
    num = 0
    Fcur = Fun(OpVal,Argume)
    Jmat, Hmat = jac_hes0(Fun,OpVal,Argume,Ranges,Fcur)
    record(num,OpVal,Fcur,Jmat,Hmat)
    check = True
    while check==True:
        num = num+1
        p_mat = np.matmul(inv(Hmat),Jmat)
        OpVal_new = [2.0*Ranges[i][2]-(OpVal[i]-p_mat[i][0]) if OpVal[i]-p_mat[i][0]>Ranges[i][2] and Ranges[i][0]==True else 2.0*Ranges[i][1]-(OpVal[i]-p_mat[i][0]) if OpVal[i]-p_mat[i][0]<Ranges[i][1] and Ranges[i][0]==True else OpVal[i]-p_mat[i][0] for i in range(0,len(OpVal))]
        Fnew,Jmat_new = jaco(Fun,OpVal_new,Argume,Ranges)
        Hmat_new = hess(OpVal,Jmat,Hmat,OpVal_new,Jmat_new)
        record(num,OpVal_new,Fnew,Jmat_new,Hmat_new)
        if abs(Fcur-Fnew)<Conver:
            check = False
        else:
            OpVal = [OpVal_new[i] for i in range(0,len(OpVal_new))]
            Fcur  = Fnew
            Jmat  = [[Jmat_new[i][j] for j in range(0,len(Jmat_new[i]))] for i in range(0,len(Jmat_new))]
            Hmat  = [[Hmat_new[i][j] for j in range(0,len(Hmat_new[i]))] for i in range(0,len(Hmat_new))]
    return Fnew,OpVal_new

def gbo_bfgs(Fun,OpVal,Argume,Ranges,Conver):
    with open('./steps.txt','w') as f:
        f.write('#####################################\n')
        f.write('# Giannis Serafeim     15 Mar. 2024 #\n')
        f.write('# PhD Mechanical Engineering - NTUA #\n')
        f.write('# Simplex method  ----  version-0.0 #\n')
        f.write('#####################################\n')
        f.write('#num   ')
        for i in range(0,len(OpVal)):
            f.write('val-%s    '%(number(i)))
        f.write('Jacobian    Hessian           evaluation\n')
    Opt,Val = bfgs(Fun,OpVal,Argume,Ranges,Conver)
    with open('./steps.txt','a+') as f:
        f.write('#####################################\n')
        for i in range(0,len(Val)):
            f.write('val-%s: %.5f\n'%(number(i),Val[i]))
        f.write('-------------\nOptimum: %.5f'%(Opt))
    print('GBO: B-F-G-S')
    print('---------------')
    for i in range(0,len(Val)):
        print('val-%s: %.5f'%(number(i),Val[i]))
    print('Optimum: %.5f'%(Opt))
    return Opt,[Val[i] for i in range(0,len(Val))]
