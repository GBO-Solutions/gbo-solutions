1) topcis:
   - maximization of linear function with inequality constrains
   - used only in linear programming problems

2) running:
   opt,sol = module.gbo_simplex(Aug)
   - opt: optimal solution value
   - sol: values of optimal parameters
   - Aug: augmented matrix

2) necessary installed modules:
   - numpy

3) output file:
   - steps.txt: the results of the optimization process at each step are recorded
