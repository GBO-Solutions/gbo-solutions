import module

Aug = [[2.0,3.0,0.0,0.0, 0.0],
       [5.0,4.0,1.0,0.0,32.0],
       [1.0,2.0,0.0,1.0,10.0]]

module.gbo_simplex(Aug)
